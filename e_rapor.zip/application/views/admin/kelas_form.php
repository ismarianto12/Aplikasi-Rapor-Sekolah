<form action="" method="POST"> 
<table class="table table-striped">
		<tr><td>Nama Urutan Abjad</td><td>
		<select class="form-control" name="nama_kelas">
		<option value="A">A</option>
		<option value="B">B</option>
		<option value="C">C</option>
		<option value="E">E</option>
		</select>
		</td></tr>
		<tr><td>Nama Kelas Angka</td><td>
		<select class="form-control" name="ket">
		<option value="10">10</option>
		<option value="11">11</option>
		<option value="12">12</option>

		</select></td></tr>		 
		<tr><td><button type="submit" class="btn btn-primary" name="kirim">
					<i class="glyphicon glyphicon-floppy-disk"></i> Simpan 
				</button>
				<a class="btn btn-warning" href="#">
					<i class="glyphicon glyphicon-arrow-left"></i> Batal 
				</a></td><td></td></tr>
		 
</table>
</form>

 