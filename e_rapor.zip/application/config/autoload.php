<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
$autoload['packages'] = array(); 
$autoload['libraries'] = array('database', 'session','upload','form_validation');
$autoload['helper'] = array('url', 'file','form_web','text');
$autoload['config'] = array();
$autoload['language'] = array();
$autoload['model'] = array();
